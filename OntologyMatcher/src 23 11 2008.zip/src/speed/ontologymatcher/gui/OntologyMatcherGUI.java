package speed.ontologymatcher.gui;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import speed.ontologymatcher.gui.panels.MainPanel;

import com.jgoodies.looks.windows.WindowsLookAndFeel;

public class OntologyMatcherGUI extends JFrame {

	private static final long serialVersionUID = 1L;
	
	private JPanel jContentPane = null;

	/**
	 * This is the default constructor
	 */
	public OntologyMatcherGUI() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		try {
			UIManager.setLookAndFeel(new WindowsLookAndFeel());
		} catch (UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.setSize(800, 600);
		this.setResizable(false);
		this.setContentPane(getJContentPane());
		this.setTitle("SPEED");
		this.setContentPane(new MainPanel());
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
		}
		return jContentPane;
	}

}
