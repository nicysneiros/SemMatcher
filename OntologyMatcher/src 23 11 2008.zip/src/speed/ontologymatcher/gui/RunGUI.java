package speed.ontologymatcher.gui;

public class RunGUI {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OntologyMatcherGUI speed = new OntologyMatcherGUI();
		speed.setVisible(true);
	}

}
