package speed.ontologymatcher.semanticmatching.matcher;

import java.util.ArrayList;

import speed.ontologymatcher.lematching.basics.LEAlignment;
import speed.ontologymatcher.lematching.enums.EMappingType;
import speed.ontologymatcher.lematching.enums.EMatcher;
import speed.ontologymatcher.lematching.matcher.LEMatcherManager;
import speed.ontologymatcher.semanticmatching.basics.Alignment;
import speed.ontologymatcher.semanticmatching.basics.ESSMFunction;
import speed.ontologymatcher.semanticmatching.jena.Inference;
import speed.ontologymatcher.semanticmatching.jena.ModelUtilities;
import speed.ontologymatcher.sparql.StorageManager;
import speed.ontologymatcher.util.OntologyMatcherProperties;

import com.hp.hpl.jena.rdf.model.Model;

/**
 * Classe com m�todos para c�lculo de alinhamentos sem�nticos.
 * 
 * @author Thiago Pach�co Andrade Pereira
 * 
 */
public class SemanticMatcher {

	/**
	 * M�todo que executa o matching sem�ntico.
	 * 
	 * @param fileCLOi Caminho da ontologia local CLOi.
	 * @param fileCLOj Caminho da ontologia local CLOj.
	 * @param fileCMO Caminho da ontologia local CMO.
	 * @return Retorna uma lista de alinhamentos sem�nticos.
	 */
	public ArrayList<Alignment> executeSemanticMatching(String fileCLOi,
			String fileCLOj, String fileCMO) {
		ArrayList<Alignment> semanticAlignments = null;
		
		// Matching lingu�stico-estrutural
		LEMatcherManager matcherManager = new LEMatcherManager();
		ArrayList<ArrayList<LEAlignment>> leAlignments = matcherManager
				.executeLEMatchingWithCMO(fileCLOi, fileCLOj, fileCMO);

		// Matching-sem�ntico
		if(leAlignments.size() == 2)
		{
			Inference inference = new Inference(leAlignments.get(0), leAlignments
					.get(1), fileCMO, 1.0);
			Model matchings = inference.generateMatchingModel();
			semanticAlignments = inference
					.returnSematicAlignments(matchings);
			
			for(Alignment ali : semanticAlignments)
			{
				ali.setWeight(this.getSemanticRelationWeight(ali.getPredicate()));
			}
		}

		return semanticAlignments;
	}
	
	/**
	 * M�todo que executa o matching sem�ntico considerando ontologias normalizadas.
	 * 
	 * @param fileCLOi Caminho da ontologia local CLOi.
	 * @param fileCLOj Caminho da ontologia local CLOj.
	 * @param fileCMO Caminho da ontologia local CMO.
	 * @return Retorna uma lista de alinhamentos sem�nticos.
	 */
	public ArrayList<Alignment> executeSemanticMatchingNormalized(String fileCLOi,
			String fileCLOj, String fileCMO)
	{
		ArrayList<Alignment> semanticAlignments = null;
		
		// Matching lingu�stico-estrutural
		LEMatcherManager matcherManager = new LEMatcherManager();
		ArrayList<ArrayList<LEAlignment>> leAlignments = matcherManager
		.executeLEMatchingWithCMONormalized(fileCLOi, fileCLOj, fileCMO);

		// Matching-sem�ntico
		if(leAlignments.size() == 2)
		{
			Inference inference = new Inference(leAlignments.get(0), leAlignments
					.get(1), fileCMO, 1.0);
			Model matchings = inference.generateMatchingModel();
			semanticAlignments = inference
					.returnSematicAlignments(matchings);
			
			for(Alignment ali : semanticAlignments)
			{
				ali.setWeight(this.getSemanticRelationWeight(ali.getPredicate()));
			}
		}
		
		return semanticAlignments;
	}
	

	/**
	 * M�todo que calcula a medida de similaridade entre duas ontologias.
	 * 
	 * @param fileCLOi Caminho da ontologia local CLOi.
	 * @param fileCLOj Caminho da ontologia local CLOj.
	 * @param fileCMO Caminho da ontologia de dom�nio CMO.
	 * @param bestAlignmentsFile Caminho do arquivo com os alinhamentos finais.
	 * @return Retorna o grau de similaridade entre as duas ontologias.
	 */
	public double calculateSSM(String fileCLOi, String fileCLOj,
			String fileCMO, ESSMFunction function, String bestAlignmentsFile) {
		double measure = -1.0;

		if(OntologyMatcherProperties.NORMALIZED)
		{
			//Matching linguistico estrutural.
			LEMatcherManager matcherManager = new LEMatcherManager();
			String outPath = fileCMO.substring(0, fileCMO.lastIndexOf("\\"));
			
			ArrayList<LEAlignment> leAlignmentsCLOij = matcherManager
				.executeLEMAtching(fileCLOi, fileCLOj, outPath
					+ "/StruturalLinguisticAlignments.rdf", EMappingType.ONE_TO_MANY,
					EMatcher.LINGUISTIC_STRUCTURAL);
			
			//Matching sem�ntico
			ArrayList<Alignment> semanticAlignmentsCLOij = 
				this.executeSemanticMatchingNormalized(fileCLOi, fileCLOj, fileCMO);
			
			if(OntologyMatcherProperties.DEBUG)
			{
				StorageManager.saveToFile(semanticAlignmentsCLOij, outPath + "\\SemanticAlignments.owl");
			}
			
			ArrayList<Alignment> finalAlignmentsCLOij = this.calculateAlignmentAverage(semanticAlignmentsCLOij, leAlignmentsCLOij);
			ArrayList<Alignment> finalAlignmentsCLOji = null;
			
			
			/*if(OntologyMatcherProperties.CAROLSUGGESTION)
			{
				
				if(function == ESSMFunction.Average)
				{
					double sumAligns = 0.0;
					double numAligns = finalAlignmentsCLOij.size();
					
					for(Alignment ali : finalAlignmentsCLOij)
					{
						sumAligns += ali.getWeight();						
					}
					
					measure = sumAligns/numAligns;
					
				}
				else
				{	
					throw new RuntimeException("Para a sugestao de Carol s� foi implementado o AVERAGE!");					
				}
			}
			else
			{*/
				ArrayList<ArrayList<Alignment>> finalAlignments = this.selectMatchCandidates(finalAlignmentsCLOij);  
				
				finalAlignmentsCLOij = finalAlignments.get(0);
				finalAlignmentsCLOji = finalAlignments.get(1);				
				
				this.saveBestAlignmentsToFile(finalAlignmentsCLOij, finalAlignmentsCLOji, bestAlignmentsFile);
				
				//Pega o n�mero de conceitos.
				int numOfConceptsCLOi = ModelUtilities.getNumberOfConcepts(fileCLOi);
				int numOfConceptsCLOj = ModelUtilities.getNumberOfConcepts(fileCLOj);
				
				if(function == ESSMFunction.Average)
				{
					double sumCLOij = 0.0;
					
					for(Alignment align : finalAlignmentsCLOij)
						sumCLOij += align.getWeight();
					
					double sumCLOji = 0.0;
					
					for(Alignment align : finalAlignmentsCLOji)
						sumCLOji += align.getWeight();
					
					measure = (sumCLOij + sumCLOji)/(numOfConceptsCLOi + numOfConceptsCLOj);
					
				}
				else if(function == ESSMFunction.DICE)
				{
					double numCLOij = 0.0;
					
					for(Alignment align : finalAlignmentsCLOij)
						if(align.getWeight() > 0)
							numCLOij += 1;				
					
					double numCLOji = 0.0;
					
					for(Alignment align : finalAlignmentsCLOji)
						if(align.getWeight() > 0)
							numCLOji += 1;
					
					measure = (numCLOij + numCLOji)/(numOfConceptsCLOi + numOfConceptsCLOj);
					
				}
				
			//}
			
			
		}else{
		
			// Matching lingu�stico estrutural.		
			LEMatcherManager matcherManager = new LEMatcherManager();
			String outPath = fileCMO.substring(0, fileCMO.lastIndexOf("\\"));
			ArrayList<LEAlignment> alignmentsLECLOij = matcherManager
					.executeLEMAtching(fileCLOi, fileCLOj, outPath
							+ "/StruturalLinguisticAlignments.rdf", EMappingType.ONE_TO_MANY,
							EMatcher.LINGUISTIC_STRUCTURAL);
			ArrayList<LEAlignment> alignmentsLECLOji = matcherManager
					.executeLEMAtching(fileCLOj, fileCLOi, outPath
							+ "/StruturalLinguisticAlignments.rdf", EMappingType.ONE_TO_MANY,
							EMatcher.LINGUISTIC_STRUCTURAL);
			
			// Matching Sem�ntico.
			ArrayList<Alignment> alignmentsSemanticCLOij = this
			.executeSemanticMatching(fileCLOi, fileCLOj, fileCMO);
			ArrayList<Alignment> alignmentsSemanticCLOji = this
			.executeSemanticMatching(fileCLOj, fileCLOi, fileCMO);
			
			ArrayList<ArrayList<Alignment>> alignments11 = this.selectMatchCandidates(alignmentsSemanticCLOij); 
			
			alignmentsSemanticCLOij = alignments11.get(0);
			alignmentsSemanticCLOji = alignments11.get(1);
			
			ArrayList<Alignment> finalAlignmentsCLOij = this.calculateAlignmentAverage(alignmentsSemanticCLOij, alignmentsLECLOij);
			ArrayList<Alignment> finalAlignmentsCLOji = this.calculateAlignmentAverage(alignmentsSemanticCLOji, alignmentsLECLOji);
			
			int numO1Concepts = ModelUtilities.getNumberOfConcepts(fileCLOi);
			int numO2Concepts = ModelUtilities.getNumberOfConcepts(fileCLOj);
	
			if (function == ESSMFunction.Average) {
				double sumSimLESemanticCLOij = 0.0;
				double sumSimLESemanticCLOji = 0.0;
	
				for (Alignment align : finalAlignmentsCLOij)
					sumSimLESemanticCLOij += align.getWeight();
	
				for (Alignment align : finalAlignmentsCLOji)
					sumSimLESemanticCLOji += align.getWeight();
	
				measure = (sumSimLESemanticCLOij + sumSimLESemanticCLOji)
						/ (numO1Concepts + numO2Concepts);
			} else if (function == ESSMFunction.DICE) {
				double numAlignmentsCLOij = finalAlignmentsCLOij.size();
				double numAlignmentsCLOji = finalAlignmentsCLOji.size();
	
				measure = (numAlignmentsCLOij + numAlignmentsCLOji)
						/ (numO1Concepts + numO2Concepts);
			}
		}
		return measure;
	}

	/**
	 * M�todo auxiliar que diminui os relacionamentos 1:N em 1:1 selecionando os melhores candidatos.
	 * 
	 * @param alignments1N Todos alinhamentos sem�nticos.
	 * @return Retorna alinhamentos 1:1.
	 */
	private ArrayList<ArrayList<Alignment>> selectMatchCandidates(ArrayList<Alignment> alignments1N)
	{
		ArrayList<ArrayList<Alignment>> alignments = new ArrayList<ArrayList<Alignment>>();
		
		ArrayList<Alignment> bestAlignments11_1 = new ArrayList<Alignment>();
		ArrayList<Alignment> bestAlignments11_2 = new ArrayList<Alignment>();
		ArrayList<Alignment> selectedAlignments11_1 = new ArrayList<Alignment>();
		ArrayList<Alignment> selectedAlignments11_2 = new ArrayList<Alignment>();
		
		
		//Seleciona melhores alinhamentos na "ida"
		ArrayList<String> subjects = new ArrayList<String>();

		for (Alignment align : alignments1N) {
			if (!subjects.contains(align.getSubject()))
				subjects.add(align.getSubject());
		}
		
		for(int i = 0; i < subjects.size(); i++)
		{
			String sub = subjects.get(i);
			int indexSub = -1;
			
			double biggersemanticRelation = -1.0;
			
			for (int j = 0; j < alignments1N.size(); j++) {
				Alignment align = alignments1N.get(j);
				if (align.getSubject().equals(sub)
						&& align.getWeight() > biggersemanticRelation) {
					biggersemanticRelation = align.getWeight();
					indexSub = j;
				}
			}

			if (indexSub != -1 && biggersemanticRelation > 0.0) {
				bestAlignments11_1.add(alignments1N.get(indexSub));
			}			
		}
		
		// Seleciona melhores alinhamentos na "volta"
		subjects = new ArrayList<String>();
		
		for (Alignment align : alignments1N) {
			if (!subjects.contains(align.getObject()))
				subjects.add(align.getObject());
		}
		
		for(int i = 0; i < subjects.size(); i++)
		{
			String sub = subjects.get(i);
			int indexSub = -1;
			
			double biggersemanticRelation = -1.0;
			
			for (int j = 0; j < alignments1N.size(); j++) {
				Alignment align = alignments1N.get(j);
				if (align.getObject().equals(sub)
						&& align.getWeight() > biggersemanticRelation) {
					biggersemanticRelation = align.getWeight();
					indexSub = j;
				}
			}

			if (indexSub != -1 && biggersemanticRelation > 0.0) {
				Alignment invertedAlign = new Alignment();
				invertedAlign.setSubject(alignments1N.get(indexSub).getObject());
				invertedAlign.setObject(alignments1N.get(indexSub).getSubject());
				invertedAlign.setPredicate(alignments1N.get(indexSub).getPredicate());
				invertedAlign.setWeight(alignments1N.get(indexSub).getWeight());				
				bestAlignments11_2.add(invertedAlign);
			}			
		}
		
		//Faz verifica��o do COMA de se existe nos dois lados o relacionamento.
		
		for(Alignment ali1 : bestAlignments11_1)
		{
			boolean contains = false;
			
			for (Alignment ali2 : bestAlignments11_2)
			{	
				if(ali1.getSubject().equals(ali2.getObject())
						&& ali1.getObject().equals(ali2.getSubject())
						//&& ali1.getPredicate().equals(ali2.getPredicate())
						)
				{
					contains = true;
				}
			}
			
			if(contains)
			{
				selectedAlignments11_1.add(ali1);
			}
		}
		
		for(Alignment ali2 : bestAlignments11_2)
		{
			boolean contains = false;
			
			for (Alignment ali1 : bestAlignments11_1)
			{	
				if(ali2.getSubject().equals(ali1.getObject())
						&& ali2.getObject().equals(ali1.getSubject())
						//&& ali2.getPredicate().equals(ali1.getPredicate())
						)
				{
					contains = true;
				}
			}
			
			if(contains)
			{
				selectedAlignments11_2.add(ali2);
			}
		}
		
		alignments.add(selectedAlignments11_1);
		alignments.add(selectedAlignments11_2);
		
		return alignments;
	}
		
	/**
	 * M�todo auxiliar para pegar valor de cada relacionamento sem�ntico.
	 * 
	 * @param predicate Predicado do relacionamento sem�ntico.
	 * @return Valor do relacionamento sem�ntico.
	 */
	private double getSemanticRelationWeight(String predicate) {
		double weight = -1.0;

		if (predicate.contains("isEquivalentTo")) {
			weight = 1.0;
		} else if (predicate.contains("isSubConceptOf")) {
			weight = 0.8;
		} else if (predicate.contains("isSuperConceptOf")) {
			weight = 0.8;
		} else if (predicate.contains("isPartOf")
				|| predicate.contains("isWholeOf")) {
			weight = 0.3;
		} else if (predicate.contains("isDisjointWith")) {
			weight = 0.0;
		} else if (predicate.contains("isCloseTo")) {
			weight = 0.7;
		}

		return weight;
	}
	
	/**
	 * M�todo que calcula a m�dia dos pesos sem�nticos e lingu�stico-estruturais.
	 * @param semanticAlignments Alinhamentos sem�nticos.
	 * @param leAlignments Alinhamentos lingu�stico-estruturais.
	 * @return Lista de alinhamentos com a m�dia calculada.
	 */
	private ArrayList<Alignment> calculateAlignmentAverage(
			ArrayList<Alignment> semanticAlignments, ArrayList<LEAlignment> leAlignments) {
		
		ArrayList<Alignment> finalAlignments = new ArrayList<Alignment>();		
		
		for (LEAlignment statement : leAlignments) {

			String subject = statement.getClass1();
			String predicate = "";
			String object = statement.getClass2();

			double similarity = 0.0;

			if (subject != null && object != null)
			{	
				
				for (Alignment matItem : semanticAlignments) {
					if (subject.equals(matItem.getSubject())
							&& object.equals(matItem.getObject())) {
						
						predicate = matItem.getPredicate();
						similarity = matItem.getWeight()
								* OntologyMatcherProperties.LE_WEIGHT
								+ matItem.getWeight()
								* OntologyMatcherProperties.SEMANTIC_WEIGHT;
					}
				}
			}

			Alignment speedStatement = new Alignment();
			speedStatement.setSubject(subject);
			speedStatement.setPredicate(predicate);
			speedStatement.setObject(object);
			speedStatement.setWeight(similarity);

			finalAlignments.add(speedStatement);
		}
		
		return finalAlignments;
	}

	/**
	 * M�todo que salva em um arquivo os melhores alinhamentos.
	 * @param alignmentsO1O2 Alinhamentos de ida.
	 * @param alignmentsO2O1 Alinhamentos de volta.
	 * @param path Caminho do arquivo
	 */
	private void saveBestAlignmentsToFile(ArrayList<Alignment> alignmentsO1O2, ArrayList<Alignment> alignmentsO2O1, String path)
	{
		ArrayList<Alignment> finalAlignments = new ArrayList<Alignment>();
		
		for(Alignment alignO1O2 : alignmentsO1O2)
		{
			for(Alignment alignO2O1 : alignmentsO2O1)
			{
				if(alignO1O2.getSubject().equals(alignO2O1.getObject())
					&& alignO1O2.getObject().equals(alignO2O1.getSubject())
					&& alignO1O2.getPredicate().equals(alignO2O1.getPredicate())
				)
				{
					Alignment align = new Alignment();
					align.setSubject(alignO1O2.getSubject());
					align.setPredicate(alignO1O2.getPredicate());
					align.setObject(alignO1O2.getObject());
					
					double weight = 0.0;
					
					if(alignO1O2.getWeight() > alignO1O2.getWeight())
					{	
						weight = alignO1O2.getWeight();
					}
					else
					{
						weight = alignO2O1.getWeight();						
					}
					
					align.setWeight(weight);
					
					finalAlignments.add(align);					
				}
			}
		}
		
		StorageManager.saveToFile(finalAlignments, path);
		
	}
	
}
