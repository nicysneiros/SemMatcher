package speed.ontologymatcher.semanticmatching.jena;

import java.net.URI;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import org.semanticweb.owl.apibinding.OWLManager;
import org.semanticweb.owl.model.OWLEntity;
import org.semanticweb.owl.model.OWLOntology;
import org.semanticweb.owl.model.OWLOntologyCreationException;
import org.semanticweb.owl.model.OWLOntologyManager;
import org.semanticweb.owl.model.OWLPropertyAxiom;
import org.semanticweb.owl.model.OWLPropertyDomainAxiom;
import org.semanticweb.owl.model.OWLPropertyRangeAxiom;

import speed.ontologymatcher.lematching.basics.LEAlignment;
import speed.ontologymatcher.semanticmatching.basics.Alignment;
import speed.ontologymatcher.semanticmatching.basics.SPEEDProperty;
import speed.ontologymatcher.sparql.QueryManager;
import speed.ontologymatcher.sparql.SpeedStatement;
import speed.ontologymatcher.util.OntologyMatcherProperties;

import com.hp.hpl.jena.ontology.OntClass;
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.ontology.OntModelSpec;
import com.hp.hpl.jena.ontology.ProfileRegistry;
import com.hp.hpl.jena.rdf.model.InfModel;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.reasoner.rulesys.GenericRuleReasoner;
import com.hp.hpl.jena.reasoner.rulesys.Rule;
import com.hp.hpl.jena.util.FileManager;
import com.hp.hpl.jena.util.PrintUtil;
import com.hp.hpl.jena.util.iterator.ExtendedIterator;
import com.hp.hpl.jena.vocabulary.RDFS;

/**
 * Classe que encapsula opera��es relativas a infer�ncias geradas pelo Jena.
 * 
 * @author Thiago Pach�co Andrade Pereira.
 * 
 */
public class Inference {

	private String uriCMO;

	private ArrayList<LEAlignment> matchingsCLOi;

	private ArrayList<LEAlignment> matchingsCLOj;

	private ArrayList<String> roots;

	private OntModel model;

	private Model schema;

	private Model inferredModel;
	
	private OWLOntology ontology;

	private ArrayList<Alignment> matchingStatements;

	private int threshold = 3;

	public int getThreshold() {
		return threshold;
	}

	public void setThreshold(int threshold) {
		this.threshold = threshold;
	}

	public ArrayList<Alignment> getMatchingStatements() {
		return matchingStatements;
	}

	public void setMatchingStatements(ArrayList<Alignment> matchingStatements) {
		this.matchingStatements = matchingStatements;
	}

	/**
	 * Contrutor da classe Inference.
	 * 
	 * @param matchingsCLOi
	 * @param matchingsCLOj
	 * @param ontologyPathCMO
	 * @param minMeasure
	 */
	public Inference(ArrayList<LEAlignment> matchingsCLOi,
			ArrayList<LEAlignment> matchingsCLOj, String ontologyPathCMO,
			double minMeasure) {
		
		String ontologyPath = "file:/" + ontologyPathCMO;
		
		this.schema = FileManager.get().loadModel(ontologyPath);
		
		OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
		
		try {
			this.ontology = manager.loadOntologyFromPhysicalURI(URI.create(ontologyPath.replace('\\', '/')));
		} catch (OWLOntologyCreationException e) {
			e.printStackTrace();
		}
		
		StmtIterator subIt = this.schema.listStatements(null, RDFS.subClassOf,
				(RDFNode) null);

		while (subIt.hasNext()) {
			Statement subStmt = (Statement) subIt.next();

			if (subStmt.getObject() != null && subStmt.getSubject() != null) {
				Resource subject = this.schema.createResource(subStmt
						.getObject().toString());
				Property predicate = this.schema
						.createProperty(OntologyMatcherProperties.SPEED_URI
								+ "superClassOf");
				Resource object = this.schema.createResource(subStmt
						.getSubject().getURI());

				if (!this.schema.contains(subject, predicate, object))
					this.schema.add(subject, predicate, object);
			}
		}
		
		StmtIterator subIt2 = this.schema.listStatements(null, RDFS.subPropertyOf,
				(RDFNode) null);
		
		while (subIt2.hasNext()) {
			Statement subStmt = (Statement) subIt2.next();

			if (subStmt.getObject() != null && subStmt.getSubject() != null) {
				Resource subject = this.schema.createResource(subStmt
						.getObject().toString());
				Property predicate = this.schema
						.createProperty(OntologyMatcherProperties.SPEED_URI
								+ "superPropertyOf");
				Resource object = this.schema.createResource(subStmt
						.getSubject().getURI());

				if (!this.schema.contains(subject, predicate, object))
					this.schema.add(subject, predicate, object);
			}
		}

		OntModelSpec spec = new OntModelSpec(OntModelSpec.OWL_DL_MEM_TRANS_INF);
		this.model = ModelFactory.createOntologyModel(spec, this.schema);
		this.matchingsCLOi = matchingsCLOi;
		this.matchingsCLOj = matchingsCLOj;

		// Pega roots
		this.roots = new ArrayList<String>();

		for (Iterator i = model.listClasses(); i.hasNext();) {
			OntClass c = (OntClass) i.next();

			Resource resourceLocalClass = this.model.createResource(c.getURI());
			Resource resourceDomainClass = this.model
					.createResource(c.getURI());
			Property propertyEquivalentClass = this.model
					.createProperty(OntologyMatcherProperties.EQUIVALENT_CLASS);

			if (!this.model.contains(resourceLocalClass,
					propertyEquivalentClass,
					OntologyMatcherProperties.CLASS_URI)) {
				this.model.add(resourceLocalClass, propertyEquivalentClass,
						resourceDomainClass);
			}

			if (c.isHierarchyRoot())
				this.roots.add(c.getURI());
		}

		// Seta URIs
		this.uriCMO = model.getNsPrefixURI("");

		this.addMatchingsToModel(matchingsCLOi, matchingsCLOj, minMeasure);
	}

	/**
	 * M�todo auxiliar que adiciona classes equivalentes dos alinhamentos no
	 * model da classe (CMO).
	 * 
	 * @param matchingsCLOi Lista de alinhamentos da classe CLOi com CMO.
	 * @param matchingsCLOj Lista de alinhamentos da classe CLOj com CMO.
	 * @param minMeasure Medida m�nima necess�ria pra considerar a classe como equivalente.
	 */
	private void addMatchingsToModel(ArrayList<LEAlignment> matchingsCLOi,
			ArrayList<LEAlignment> matchingsCLOj, double minMeasure) {

		if (matchingsCLOi != null)
			for (LEAlignment itemCLOi : matchingsCLOi) {
				Resource resourceLocalClass = this.model
						.createResource(itemCLOi.getClass1());
				Resource resourceDomainClass = this.model
						.createResource(itemCLOi.getClass2());
				Property propertyTypeOf = this.model
						.createProperty(OntologyMatcherProperties.TYPE_OF_URI);
				Property propertyEquivalentClass = this.model
						.createProperty(OntologyMatcherProperties.EQUIVALENT_CLASS);

				if (!this.model.contains(resourceLocalClass, propertyTypeOf,
						OntologyMatcherProperties.CLASS_URI)
						&& itemCLOi.getMeasure() >= minMeasure) {
					this.model.add(resourceLocalClass, propertyTypeOf,
							OntologyMatcherProperties.CLASS_URI);
					this.model.add(resourceLocalClass, propertyEquivalentClass,
							resourceDomainClass);
				}
			}

		if (matchingsCLOj != null)
			for (LEAlignment itemCLOj : matchingsCLOj) {
				Resource resourceLocalClass = this.model
						.createResource(itemCLOj.getClass1());
				Resource resourceDomainClass = this.model
						.createResource(itemCLOj.getClass2());
				Property propertyTypeOf = this.model
						.createProperty(OntologyMatcherProperties.TYPE_OF_URI);
				Property propertyEquivalentClass = this.model
						.createProperty(OntologyMatcherProperties.EQUIVALENT_CLASS);

				if (!this.model.contains(resourceLocalClass, propertyTypeOf,
						OntologyMatcherProperties.CLASS_URI)
						&& itemCLOj.getMeasure() >= minMeasure) {
					this.model.add(resourceLocalClass, propertyTypeOf,
							OntologyMatcherProperties.CLASS_URI);
					this.model.add(resourceLocalClass, propertyEquivalentClass,
							resourceDomainClass);
				}
			}
	}

	/**
	 * M�todo auxiliar que gera as regras do Jena entre 2 alinhamentos com a
	 * CMO.
	 * 
	 * @param CLOiClass Classe da ontologia local 1.
	 * @param CLOjClass Classe da ontologia local 2.
	 * @param CMOkClass Classe da ontologia de dom�nio 1.
	 * @param CMOzClass Classe da ontologia de dom�nio 2.
	 * @return
	 */
	private String formatRules(String CLOiClass, String CLOjClass,
			String CMOkClass, String CMOzClass) {
		String rules = "";

		boolean isClass = this.model.getOntClass(CMOkClass) != null && this.model.getOntClass(CMOzClass) != null;
		
		// isEquivalentTo
		// Rule: if CLOi:x = CMO:k and CLOj:y = CMO:k then CLOi:x isEquivalentTo
		// CLOj:y.

		rules += "[findEquivalent: ( " + CLOiClass + "  owl:equivalentClass "
				+ CMOkClass + " ) " + " ( " + CLOjClass
				+ " owl:equivalentClass " + CMOzClass + "  )" + " ( "
				+ CMOkClass + " owl:equivalentClass " + CMOzClass + "  )"
				+ " -> ( " + CLOiClass + " speed:isEquivalentTo " + CLOjClass
				+ " )" + "] ";

		
		if(isClass)
		{
			if (!CMOkClass.equals(CMOzClass)) {
				// isSubConceptOf
				// Rule: if CLOi:x = CMO:k and CLOj:y = CMO:z and CMO:k subClass
				// CMO:z
				// then CLOi:x isSubConceptOf CLOj:y.
	
				rules += "[findSubConcept: ( " + CLOiClass
						+ "  owl:equivalentClass " + CMOkClass + " ) " + " ( "
						+ CLOjClass + " owl:equivalentClass " + CMOzClass + "  )"
						+ " ( " + CMOkClass + " rdfs:subClassOf " + CMOzClass
						+ "  )" + " -> ( " + CLOiClass + " speed:isSubConceptOf "
						+ CLOjClass + " )" + "] ";
	
				// isSuperConceptOf
				// Rule: if CLOi:x = CMO:k and CLOj:y = CMO:z and CMO:k superClassOf
				// CMO:z then CLOi:x isSuperConceptOf CLOj:y.
	
				rules += "[findSuperConcept: ( " + CLOiClass
						+ "  owl:equivalentClass " + CMOkClass + " ) " + " ( "
						+ CLOjClass + " owl:equivalentClass " + CMOzClass + "  )"
						+ " ( " + CMOkClass + " "
						+ OntologyMatcherProperties.SPEED_URI + "superClassOf "
						+ CMOzClass + "  )" + " -> ( " + CLOiClass
						+ " speed:isSuperConceptOf " + CLOjClass + " )" + "] ";
			}
		}
		else
		{
			if (!CMOkClass.equals(CMOzClass)) {
				// isSubConceptOf
				// Rule: if CLOi:x = CMO:k and CLOj:y = CMO:z and CMO:k subClass
				// CMO:z
				// then CLOi:x isSubConceptOf CLOj:y.
	
				rules += "[findSubConcept: ( " + CLOiClass
						+ "  owl:equivalentClass " + CMOkClass + " ) " + " ( "
						+ CLOjClass + " owl:equivalentClass " + CMOzClass + "  )"
						+ " ( " + CMOkClass + " rdfs:subPropertyOf " + CMOzClass
						+ "  )" + " -> ( " + CLOiClass + " speed:isSubConceptOf "
						+ CLOjClass + " )" + "] ";
	
				// isSuperConceptOf
				// Rule: if CLOi:x = CMO:k and CLOj:y = CMO:z and CMO:k superClassOf
				// CMO:z then CLOi:x isSuperConceptOf CLOj:y.
	
				rules += "[findSuperConcept: ( " + CLOiClass
						+ "  owl:equivalentClass " + CMOkClass + " ) " + " ( "
						+ CLOjClass + " owl:equivalentClass " + CMOzClass + "  )"
						+ " ( " + CMOkClass + " "
						+ OntologyMatcherProperties.SPEED_URI + "superPropertyOf "
						+ CMOzClass + "  )" + " -> ( " + CLOiClass
						+ " speed:isSuperConceptOf " + CLOjClass + " )" + "] ";
			}
		}

		// isPartOf
		// Rule: if CLOi:x = CMO:k and CLOj:y = CMO:z and CMO:k PartOf CMO:z
		// then CLOi:x IsPartOf CLOj:y.

		/*
		 * Funciona apenas para o caso de um domain
		 */
		rules += "[findPartOf: ( " + CLOiClass + "  owl:equivalentClass "
				+ CMOkClass + " ) " + " ( " + CLOjClass
				+ " owl:equivalentClass " + CMOzClass + "  )"
				+ " ( CMO:PartOf rdfs:domain " + CMOkClass + " )"
				+ " ( CMO:PartOf rdfs:range " + CMOzClass + "  )" + " -> ( "
				+ CLOiClass + " speed:isPartOf " + CLOjClass + " )" + "] ";
		/*
		 * Funciona para o caso de collection (unionOf)
		 */
		/*
		 * rules += "[findPartOf: ( " + CLOiClass + " owl:equivalentClass " +
		 * CMOkClass + " ) " + " ( " + CLOjClass + " owl:equivalentClass " +
		 * CMOzClass + " )" + " ( CMO:PartOf rdfs:domain ?class )" + " ( ?class
		 * owl:unionOf ?list )" + " listContains(?list , " + CMOkClass + " ) " + " (
		 * CMO:PartOf rdfs:range " + CMOzClass + " )" + " -> ( " + CLOiClass + "
		 * speed:isPartOf " + CLOjClass + " )" + "] ";
		 */

		// isWholeOf
		/*
		 * Funciona apenas para o caso de um domain
		 */
		rules += "[findWholeOf: ( " + CLOiClass + "  owl:equivalentClass "
				+ CMOkClass + " ) " + " ( " + CLOjClass
				+ " owl:equivalentClass " + CMOzClass + "  )"
				+ " ( CMO:PartOf rdfs:domain " + CMOkClass + " )"
				+ " ( CMO:PartOf rdfs:range " + CMOzClass + "  )" + " -> ( "
				+ CLOjClass + " speed:isWholeOf " + CLOiClass + " )" + "] ";

		/*
		 * Funciona para o caso de collection (unionOf)
		 */
		/*
		 * rules += "[findWholeOf: ( " + CLOiClass + " owl:equivalentClass " +
		 * CMOkClass + " ) " + " ( " + CLOjClass + " owl:equivalentClass " +
		 * CMOzClass + " )" + " ( CMO:PartOf rdfs:domain ?class )" + " ( ?class
		 * owl:unionOf ?list )" + " listContains(?list , " + CMOkClass + " ) " + " (
		 * CMO:PartOf rdfs:range " + CMOzClass + " )" + " -> " + "( " +
		 * CLOjClass + " speed:isWholeOf " + CLOiClass + " )" + "] ";
		 */

		return rules;
	}

	/**
	 * M�todo auxiliar que verifica a regra isDisjointWith.
	 * 
	 * @param class1 Classe 1.
	 * @param class2 Classe 2.
	 * @return True - Se � isDisjointWith.
	 */
	private boolean isDisjointWith(String class1, String class2) {

		OntClass ontClass1 = this.model.getOntClass(class1);
		OntClass ontClass2 = this.model.getOntClass(class2);

		// Tempor�rio
		if (ontClass1 == null || ontClass2 == null)
			return false;

		boolean isDisjoint = ontClass1.isDisjointWith(ontClass2);
				
		return isDisjoint;		
	}

	/**
	 * M�todo auxiliar que verifica a regra isCloseTo.
	 * 
	 * @param class1 Classe 1.
	 * @param class2 Classe 2.
	 * @return True - Se � isCloseTo.
	 */
	private boolean isCloseTo(String class1, String class2) {

		OntClass ontClass1 = this.model.getOntClass(class1);
		OntClass ontClass2 = this.model.getOntClass(class2);

		// Tempor�rio para so tratar classes
		if (ontClass1 == null || ontClass2 == null)
			return false;

		boolean isCloseTo = false;

		Property subClassOf = this.schema.createProperty(RDFS.getURI()
				+ "subClassOf");

		String classA = null;
		
		for (int i = 1; i <= threshold; i++) {

			// SUBIR NA �RVORE

			ArrayList<String> superClasses = new ArrayList<String>();
			superClasses.add(class1);

			ArrayList<String> superClassesTmp = new ArrayList<String>();

			ArrayList<String> lastClassesVisited = new ArrayList<String>();
			lastClassesVisited.add(class1);

			for (int j = 0; j < i; j++) {

				for (String clazz : superClasses) {
					Resource rscrClassTmp = this.schema.createResource(clazz);

					StmtIterator it = this.schema.listStatements(rscrClassTmp,
							subClassOf, (RDFNode) null);

					lastClassesVisited.add(clazz);

					while (it.hasNext()) {
						Statement stmt = it.nextStatement();

						superClassesTmp.add(stmt.getObject().toString());
					}
				}
				superClasses.clear();

				superClasses.addAll(superClassesTmp);

				superClassesTmp.clear();
			}

			
			
			if (superClasses.size() == 0)
			{
				break;
			}
			else
			{
				classA = superClasses.get(0);				
			}

			// Desce na �rvore

			ArrayList<String> subClasses = new ArrayList<String>();
			for (String superrClass : superClasses) {
				Resource rscrClassTmp = this.schema.createResource(superrClass);

				StmtIterator it = this.schema.listStatements(null, subClassOf,
						rscrClassTmp);

				while (it.hasNext()) {
					Statement stmt = it.nextStatement();
					String clazz = stmt.getSubject().getURI();
					if (!lastClassesVisited.contains(clazz))
						subClasses.add(clazz);
				}
			}

			if (subClasses.contains(class2))
				isCloseTo = true;

			ArrayList<String> subClassesTmp = new ArrayList<String>();

			for (int j = 1; j < threshold; j++) {

				for (String clazz : subClasses) {
					Resource rscrClassTmp = this.schema.createResource(clazz);

					StmtIterator it = this.schema.listStatements(null,
							subClassOf, rscrClassTmp);

					while (it.hasNext()) {
						Statement stmt = it.nextStatement();

						subClassesTmp.add(stmt.getSubject().getURI());
					}
				}
				subClasses.addAll(subClassesTmp);

				if (subClasses.contains(class2))
					isCloseTo = true;

				subClassesTmp.clear();
			}
		}
		
		if(isCloseTo && classA != null)
		{
			Resource rscrClassTmp = this.schema.createResource(classA);
			String currentClass = classA;
			int classARootHeight = 1;
			
			boolean getRoot = false;
			boolean isValid = true;
			while(!getRoot)
			{
				StmtIterator it = this.schema.listStatements(rscrClassTmp,
						subClassOf, (RDFNode) null);
				
				boolean hasSuperClass = false;
				
				while (it.hasNext()) {
					
					hasSuperClass = true;
					Statement stmt = it.nextStatement();
					currentClass = stmt.getObject().toString();
					OntClass clazzTmp = this.model.getOntClass(currentClass);
					rscrClassTmp = clazzTmp;
					if(clazzTmp != null && clazzTmp.isHierarchyRoot())
						getRoot = true;					
					
					if(clazzTmp == null)
					{
						isValid = false;
				
					}
				}
				
				if(!isValid || !hasSuperClass)
					break;
				
				
				classARootHeight++;
			}
			
			isCloseTo = classARootHeight > OntologyMatcherProperties.THRESHOLD_ROOT
			&& !ontClass1.isDisjointWith(ontClass2) && isValid;
			
		}
		
		boolean isEqual = class1.equals(class2);

		return isCloseTo && !isEqual;
	}

	/**
	 * M�todo auxliar que gera o modelo inferido com as regras do Jena.
	 * 
	 * @param model Modelo onde vai ser aplicado as regras.
	 * @return Modelo com as infer�ncias obtidas a partir das regras.
	 */
	@SuppressWarnings("unchecked")
	private InfModel generateInferredModel(Model model) {
		PrintUtil.registerPrefix("speed", OntologyMatcherProperties.SPEED_URI);
		PrintUtil.registerPrefix("CMO", this.uriCMO);

		List rules = new Vector();

		for (LEAlignment itemCLOi : this.matchingsCLOi) {
			for (LEAlignment itemCLOj : this.matchingsCLOj) {
				if (itemCLOj != null) {
					
					if(OntologyMatcherProperties.USE_JENA)
					{
						rules.addAll(Rule.parseRules(this.formatRules(itemCLOi
								.getClass1(), itemCLOj.getClass1(), itemCLOi
								.getClass2(), itemCLOj.getClass2())));
					}
					else
					{
						if (itemCLOi.getMeasure() == 1.0
								&& itemCLOj.getMeasure() == 1.0) {
							//Equivalent
							if(this.isEquivalentTo(itemCLOi.getClass2(),
									itemCLOj.getClass2()))
							{							
								Resource resourceSubject = this.model
								.createResource(itemCLOi.getClass1());
								Property propertyPredicate = this.model
										.createProperty(OntologyMatcherProperties.SPEED_URI
												+ "isEquivalentTo");
			
								this.model.add(resourceSubject, propertyPredicate,
										itemCLOj.getClass1());
							}
							//SubConcept
							if(this.isSubConceptOf(itemCLOi.getClass2(),
									itemCLOj.getClass2()))
							{							
								Resource resourceSubject = this.model
								.createResource(itemCLOi.getClass1());
								Property propertyPredicate = this.model
										.createProperty(OntologyMatcherProperties.SPEED_URI
												+ "isSubConceptOf");
			
								this.model.add(resourceSubject, propertyPredicate,
										itemCLOj.getClass1());
							}
							
							//SuperConcept
							if(this.isSubConceptOf(itemCLOj.getClass2(),
									itemCLOi.getClass2()))
							{							
								Resource resourceSubject = this.model
								.createResource(itemCLOj.getClass1());
								Property propertyPredicate = this.model
										.createProperty(OntologyMatcherProperties.SPEED_URI
												+ "isSuperConceptOf");
			
								this.model.add(resourceSubject, propertyPredicate,
										itemCLOi.getClass1());
							}
							
							//IsPartOf
							if(this.isPartOf(itemCLOj.getClass2(),
									itemCLOi.getClass2()))
							{							
								Resource resourceSubject = this.model
								.createResource(itemCLOj.getClass1());
								Property propertyPredicate = this.model
										.createProperty(OntologyMatcherProperties.SPEED_URI
												+ "isPartOf");
			
								this.model.add(resourceSubject, propertyPredicate,
										itemCLOi.getClass1());
							}
							
							//IsWholeOf
							if(this.isPartOf(itemCLOi.getClass2(),
									itemCLOj.getClass2()))
							{							
								Resource resourceSubject = this.model
								.createResource(itemCLOj.getClass1());
								Property propertyPredicate = this.model
										.createProperty(OntologyMatcherProperties.SPEED_URI
												+ "isWholeOf");
			
								this.model.add(resourceSubject, propertyPredicate,
										itemCLOi.getClass1());
							}
						}
					}

					if (itemCLOi.getMeasure() == 1.0
							&& itemCLOj.getMeasure() == 1.0) {

						if (this.isDisjointWith(itemCLOi.getClass2(),
								itemCLOj.getClass2())) {
							Resource resourceSubject = this.model
									.createResource(itemCLOi.getClass1());
							Property propertyPredicate = this.model
									.createProperty(OntologyMatcherProperties.SPEED_URI
											+ "isDisjointWith");

							this.model.add(resourceSubject, propertyPredicate,
									itemCLOj.getClass1());
						}

						if (this.isCloseTo(itemCLOi.getClass2(), itemCLOj
								.getClass2())) {
							Resource resourceSubject = this.model
									.createResource(itemCLOi.getClass1());
							Property propertyPredicate = this.model
									.createProperty(OntologyMatcherProperties.SPEED_URI
											+ "isCloseTo");

							this.model.add(resourceSubject, propertyPredicate,
									itemCLOj.getClass1());
						}
					}
				}
			}
		}
		
		InfModel modelInferred = this.model;
		
		if(OntologyMatcherProperties.USE_JENA)
		{
			GenericRuleReasoner reasoner = new GenericRuleReasoner(rules);
			modelInferred = ModelFactory.createInfModel(reasoner, this.model);
		}
			
		return modelInferred;
	}

	private boolean isSubConceptOf(String class1, String class2) {
		boolean isSubConceptOf = false;
		
		OntClass ontClass1 = this.model.getOntClass(class1);
		OntClass ontClass2 = this.model.getOntClass(class2);

		// Tempor�rio para so tratar classes
		if (ontClass1 == null || ontClass2 == null)
			return false;
		
		ExtendedIterator it = ontClass1.listSuperClasses(true);
		
		while(it.hasNext())
		{	
			if(class2.equals(it.next().toString()))
				isSubConceptOf = true;			
		}
		
		return isSubConceptOf;
	}

	private boolean isEquivalentTo(String class1, String class2) {
		OntClass ontClass1 = this.model.getOntClass(class1);
		OntClass ontClass2 = this.model.getOntClass(class2);

		// Tempor�rio para so tratar classes
		if (ontClass1 == null || ontClass2 == null)
			return false;
		
		return class1.equals(class2);
	}

	private boolean isPartOf(String class1, String class2)
	{
		boolean isPartOf = false;
		
		ArrayList<SPEEDProperty> properties = this.getProperties();
		
		for(SPEEDProperty prop : properties)
		{
			if(prop.getDomain().contains(class1) && prop.getRange().contains(class2))
				isPartOf = true;			
		}
		
		return isPartOf;
	}
	
	private ArrayList<SPEEDProperty> getProperties()
	{
		ArrayList<SPEEDProperty> properties = new ArrayList<SPEEDProperty>();
		
		//OBJECT PROPERTIES
		Iterator it =  ontology.getObjectPropertyAxioms().iterator();
		
		ArrayList<ArrayList<String>> domains = new ArrayList<ArrayList<String>>();
		ArrayList<ArrayList<String>> ranges = new ArrayList<ArrayList<String>>();
		
		while(it.hasNext())
		{
			OWLPropertyAxiom ax = (OWLPropertyAxiom) it.next();
			
			ArrayList<String> domain = new ArrayList<String>();
			ArrayList<String> range = new ArrayList<String>();
			
			if(ax instanceof OWLPropertyDomainAxiom)
			{				
				OWLPropertyDomainAxiom a = (OWLPropertyDomainAxiom) ax;
				
				Iterator it2 = a.getReferencedEntities().iterator();
				
				while (it2.hasNext())
				{
					
					OWLEntity entity = (OWLEntity) it2.next();
					if(!entity.isOWLObjectProperty())
						domain.add(entity.getURI().toString());
				}
				domains.add(domain);
			}
			else if(ax instanceof OWLPropertyRangeAxiom)
			{
				OWLPropertyRangeAxiom a = (OWLPropertyRangeAxiom) ax;
				Iterator it2 = a.getReferencedEntities().iterator();
				
				while (it2.hasNext())
				{
					OWLEntity entity = (OWLEntity) it2.next();
					if(!entity.isOWLObjectProperty())
						range.add(entity.getURI().toString());
				}
				ranges.add(range);
			}
		}
		
		if(domains.size() == ranges.size())
		{
			SPEEDProperty prop = null;
			
			for(int i = 0; i < domains.size(); i++)
			{
				prop = new SPEEDProperty();
				
				for(String dom : domains.get(i))
				{
					prop.getDomain().add(dom);										
				}
				
				
				for(String ran : ranges.get(i))
				{
					prop.getRange().add(ran);
				}
				properties.add(prop);
			}
			
		}
		
		return properties;
	}
	
	
	/**
	 * M�todo que gera o modelo inferido com as regras do Jena (apenas os
	 * predicados do speed).
	 * 
	 * @return Retorna modelo com os relacionamentos gerados a partir das
	 *         regras.
	 */
	public Model generateMatchingModel() {
		this.inferredModel = this.generateInferredModel(this.model);
		ArrayList<Alignment> alignments = this
				.returnSematicAlignments(inferredModel);
		this.matchingStatements = alignments;
		Model matchingModel = ModelFactory
				.createOntologyModel(ProfileRegistry.RDFS_LANG);

		for (Alignment ali : alignments) {

			Resource resourceSubject = this.model.createResource(ali
					.getSubject());
			Property propertyPredicate = this.model.createProperty(ali
					.getPredicate());

			matchingModel.add(resourceSubject, propertyPredicate, ali
					.getObject());
		}

		return matchingModel;
	}

	/**
	 * M�todo que retorna uma lista de alinhamentos sem�nticos gerados pelo
	 * Jena.
	 * 
	 * @param inferredModel Modelo com dados inferidos.
	 * @return Lista com os alinhamentos do speed.
	 */
	public ArrayList<Alignment> returnSematicAlignments(Model inferredModel) {

		ArrayList<Alignment> statements = new ArrayList<Alignment>();

		QueryManager manager = new QueryManager(inferredModel);

		ArrayList<String> queries = new ArrayList<String>();
		ArrayList<String> relation = new ArrayList<String>();

		queries.add("PREFIX speed: <" + OntologyMatcherProperties.SPEED_URI
				+ "> SELECT ?x ?y WHERE { ?x speed:isEquivalentTo ?y }");
		relation.add("isEquivalentTo");

		queries.add("PREFIX speed: <" + OntologyMatcherProperties.SPEED_URI
				+ "> SELECT ?x ?y WHERE { ?x speed:isSubConceptOf ?y }");
		relation.add("isSubConceptOf");

		queries.add("PREFIX speed: <" + OntologyMatcherProperties.SPEED_URI
				+ "> SELECT ?x ?y WHERE { ?x speed:isSuperConceptOf ?y }");
		relation.add("isSuperConceptOf");

		queries.add("PREFIX speed: <" + OntologyMatcherProperties.SPEED_URI
				+ "> SELECT ?x ?y WHERE { ?x speed:isPartOf ?y }");
		relation.add("isPartOf");

		queries.add("PREFIX speed: <" + OntologyMatcherProperties.SPEED_URI
				+ "> SELECT ?x ?y WHERE { ?x speed:isWholeOf ?y }");
		relation.add("isWholeOf");

		queries.add("PREFIX speed: <" + OntologyMatcherProperties.SPEED_URI
				+ "> SELECT ?x ?y WHERE { ?x speed:isDisjointWith ?y }");
		relation.add("isDisjointWith");

		queries.add("PREFIX speed: <" + OntologyMatcherProperties.SPEED_URI
				+ "> SELECT ?x ?y WHERE { ?x speed:isCloseTo ?y }");
		relation.add("isCloseTo");

		ArrayList<SpeedStatement> tmpResults = null;

		for (int i = 0; i < queries.size(); i++) {
			tmpResults = manager.query(queries.get(i));
			for (SpeedStatement stmt : tmpResults) {
				stmt.setPredicate(OntologyMatcherProperties.SPEED_URI
						+ relation.get(i));
				Alignment alignment = new Alignment(stmt);
				statements.add(alignment);
			}
		}
		return statements;
	}

	public OntModel getModel() {
		return model;
	}

	public void setModel(OntModel model) {
		this.model = model;
	}

}
