package speed.ontologymatcher.semanticmatching.jena;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.ontology.OntModelSpec;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.util.FileManager;
import com.hp.hpl.jena.util.iterator.ExtendedIterator;

/**
 * Classe que cont�m m�todos �teis para manipular ontologias com o Jena.
 * @author Thiago Pach�co Andrade Pereira
 *
 */
public class ModelUtilities {
	
	/**
	 * M�todo que calcula o n�mero de conceitos em uma ontologia.
	 * @param path Caminho do arquivo que cont�m a ontologia.
	 * @return N�mero de conceitos.
	 */
	public static int getNumberOfConcepts(String path)
	{
		int numConcepts = 0;
		
		OntModelSpec spec = new OntModelSpec(OntModelSpec.OWL_DL_MEM_TRANS_INF);
		Model schema = FileManager.get().loadModel("file://" + path);
		OntModel model = ModelFactory.createOntologyModel(spec, schema);
		
		ExtendedIterator it = model.listClasses();
		String URI = model.getNsPrefixURI("");
		
		while (it.hasNext())
		{
			String classURI = it.next().toString();
			if(classURI.contains(URI))
				numConcepts++;
		}
		
		
		return numConcepts;
	}
}
