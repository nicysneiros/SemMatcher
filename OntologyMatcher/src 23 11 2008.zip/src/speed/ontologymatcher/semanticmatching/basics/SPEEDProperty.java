package speed.ontologymatcher.semanticmatching.basics;

import java.util.ArrayList;

public class SPEEDProperty {
	
	private ArrayList<String> domain;
	private ArrayList<String> range;
	
	public SPEEDProperty()
	{
		this.domain = new ArrayList<String>();
		this.range = new ArrayList<String>();
	}
	
	public ArrayList<String> getDomain() {
		return domain;
	}
	public void setDomain(ArrayList<String> domain) {
		this.domain = domain;
	}
	public ArrayList<String> getRange() {
		return range;
	}
	public void setRange(ArrayList<String> range) {
		this.range = range;
	}

}
