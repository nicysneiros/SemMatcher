package speed.ontologymatcher.semanticmatching.basics;

/**
 * Enum que cont�m as fun��es que podem ser usadas na gera��o da medida �nica de similaridade entre ontologias.
 * @author Thiago Pach�co Andrade Pereira
 *
 */
public enum ESSMFunction {
	Average,
	DICE
	//,Jaccard
}
