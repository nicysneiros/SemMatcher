package speed.ontologymatcher.semanticmatching.basics;

import java.util.ArrayList;

import speed.ontologymatcher.sparql.SpeedStatement;

import com.hp.hpl.jena.ontology.ProfileRegistry;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.Resource;

/**
 * Classe que representa um alinhamento sem�ntico.
 * @author Thiago Pach�co Andrade Pereira
 *
 */
public class Alignment {
	
	/**
	 * Sujeito do statement.
	 */
	private String subject;
	/**
	 * Predicado do statement.
	 */
	private String predicate;
	/**
	 * Objeto do statement.
	 */
	private String object;
	/**
	 * Valor do alinhamento.
	 */
	private double weight;
	
	public Alignment() {
		this.weight = -1.0;
	}
	
	public Alignment(SpeedStatement stmt) {
		this.subject = stmt.getSubject();
		this.predicate = stmt.getPredicate();
		this.object = stmt.getObject();
		this.weight = -1.0;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getSubject() {
		return subject;
	}
	public void setPredicate(String predicate) {
		this.predicate = predicate;
	}
	public String getPredicate() {
		return predicate;
	}
	public void setObject(String object) {
		this.object = object;
	}
	public String getObject() {
		return object;
	}
	
	/**
	 * M�todo auxiliar que cria um modelo do Jena (Model) a partir de uma lista de Alignments.
	 * @param alignments Lista de Alignments.
	 * @return Modelo do Jena contendo todos alignments.
	 */
	public static Model createJenaModelFromAlignment(ArrayList<Alignment> alignments)
	{	
		Model model = ModelFactory
		.createOntologyModel(ProfileRegistry.RDFS_LANG);

		for (Alignment ali : alignments) {
		
			Resource resourceSubject = model.createResource(ali
					.getSubject());
			Property propertyPredicate = model.createProperty(ali
					.getPredicate());
		
			model.add(resourceSubject, propertyPredicate, ali
					.getObject());
		}
		return model;
	}
	
	public static ArrayList<Alignment> invertAlignments(ArrayList<Alignment> alignments)
	{
		ArrayList<Alignment> invertedAlignments = new ArrayList<Alignment>();
		
		Alignment ali = null;
		for(Alignment align : alignments)
		{
			ali = new Alignment();
			ali.setSubject(align.getObject());
			ali.setObject(align.getSubject());
			ali.setPredicate(align.getPredicate());
			ali.setWeight(align.getWeight());
			
			invertedAlignments.add(ali);			
		}
		
		return invertedAlignments;
	}
	
}
