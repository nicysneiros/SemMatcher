package speed.ontologymatcher.tests;

import speed.ontologymatcher.lematching.enums.EMappingType;
import speed.ontologymatcher.lematching.enums.EMatcher;
import speed.ontologymatcher.lematching.matcher.LEMatcherManager;

public class Main {

	public static void main(String[] args) {
		
		String ontologiesDirectory = "D:\\CIn\\workspace\\eclipseCIn\\OntologyMatcher\\owls\\Carlos\\";
		
		String cloi = ontologiesDirectory + "LO01-Education.owl"; //AnimalCLO1.owl
		String cloj = ontologiesDirectory + "LO03-Education.owl"; //AnimalCLO1.owl
		//String cmo = ontologiesDirectory + "LO03-Education.owl"; //Organism_CMO.owl
		
		LEMatcherManager manager = new LEMatcherManager();
		
		manager.executeLEMAtching(cloi, cloj, ontologiesDirectory + "saida.owl", EMappingType.ONE_TO_ONE, EMatcher.LINGUISTIC_STRUCTURAL);
		
	}
}
