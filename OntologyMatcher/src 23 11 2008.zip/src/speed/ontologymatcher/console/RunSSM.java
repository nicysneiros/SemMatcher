package speed.ontologymatcher.console;

import speed.ontologymatcher.semanticmatching.matcher.SemanticMatcher;
import speed.ontologymatcher.semanticmatching.basics.*;

public class RunSSM {
	
	public static void main(String[] args) {
		
		SemanticMatcher sm = new SemanticMatcher();
		
		//String ontologiesDirectory = "D:\\CIn\\workspace\\eclipseCIn\\OntologyMatcher\\owls\\Testes10092008\\";
		//String ontologiesDirectory = "D:\\CIn\\workspace\\eclipseCIn\\OntologyMatcher\\owls\\Carlos2\\";
		//String ontologiesDirectory = "D:\\CIn\\workspace\\eclipseCIn\\OntologyMatcher\\owls\\DamiresPropriedades\\Sub\\";
		String ontologiesDirectory = "D:\\CIn\\workspace\\eclipseCIn\\OntologyMatcher\\owls\\Testes10092008\\";
		
		String cloi = ontologiesDirectory + "AnimalCLO1.owl";
		String cloj = ontologiesDirectory + "AnimalCLO2.owl";
		String cmo = ontologiesDirectory + "Organism_CMO.owl";
		
		double result = sm.calculateSSM(cloi, cloj, cmo, ESSMFunction.Average, ontologiesDirectory + "/AlinhamentosFinais.rdf");
		
		System.out.println("Medida: " + result);
	}
}
