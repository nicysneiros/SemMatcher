package speed.ontologymatcher.lematching.util;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;

import speed.ontologymatcher.semanticmatching.basics.Alignment;
import speed.ontologymatcher.util.OntologyMatcherProperties;

/**
 * Classe para tratamento dos arquivo de matching gerados pelas ferramentas de matching linguistico-estruturais.
 * @author Thiago Pach�co Andrade Pereira
 *
 */
public class XMLParser {
	/**
	 * Recebe um arquivo de alinhamento e um n� do xml, e retorna os valores de seus atributos.
	 * @param filePath Caminho do arquivo de alinhamentos.
	 * @param node Nome do n� do XML a ser procurado. 
	 * @return Lista de atributos do n�.
	 * @throws FileNotFoundException Lan�a uma excess�o do tipo FileNotFoundException se o arquivo n�o for encontrado. 
	 */
	@SuppressWarnings("all")
	public static ArrayList<String> findNodeInAlignmentFile(String filePath, String node) throws FileNotFoundException
	{	
		ArrayList<String> results = new ArrayList<String>();
		String fileText = "";
		
		/*Scanner scan = new Scanner(new File(filePath));
		
		while (scan.hasNextLine())
		{
			fileText += scan.nextLine();
		}
		scan.close();*/
		try{
			FileInputStream fstream = new 
	        FileInputStream(filePath);                    
		    DataInputStream in = new DataInputStream(fstream);
		                    
	        while (in.available() !=0)
		    {
	        	fileText += in.readLine();
		    }
		}catch(Exception ex)
		{
			ex.printStackTrace();		
		}
		
		fileText = fileText.replaceAll(" ", "").replaceAll("\n", "");
		
		String[] strings = fileText.split("<" + node);
		
		
		for(int i = 0; i < strings.length; i++)
		{
			String string = strings[i];
			if(string.contains("<?xmlversion=") || string.startsWith("<Match"))
				continue;
			
			int index = string.indexOf("</" + node + ">");
			
			if(index != -1)
			{
				int initialIndex = string.indexOf(">") + 1;
				
				String nodeResult = string.substring( initialIndex, index);
				results.add(nodeResult);
			}
			else
			{
				String stringTemp = string.split("/>")[0];
				
				int initialIndex = -1;
				int finalIndex = -1;
				if(OntologyMatcherProperties.MATCHER == 1 || OntologyMatcherProperties.MATCHER == 3)
				{
					initialIndex = stringTemp.indexOf("\"") + 1;
					finalIndex = stringTemp.lastIndexOf("\"");
				}
				else if(OntologyMatcherProperties.MATCHER == 2)
				{
					initialIndex = stringTemp.indexOf("'") + 1;
					finalIndex = stringTemp.lastIndexOf("'");				
				}
				
				String nodeResult = stringTemp.substring(initialIndex, finalIndex);
				
				results.add(nodeResult);
			}
			
		}
		
		return 
			results != null && results.size() > 0 ? results : null;
	}

	public static ArrayList<Alignment> getFileAlignments(String filePath) throws FileNotFoundException
	{
		ArrayList<Alignment> alignments = new ArrayList<Alignment>();
		
		
		ArrayList<String> subjects = findNodeInAlignmentFile(filePath, "Subject");
		ArrayList<String> predicates = findNodeInAlignmentFile(filePath, "Predicate");
		ArrayList<String> objects = findNodeInAlignmentFile(filePath, "Object");
		ArrayList<String> similarity = findNodeInAlignmentFile(filePath, "Similarity");
		
		int size = subjects.size(); 
		
		if(predicates.size() == size && objects.size() == size && similarity.size() == size)
		{
			Alignment align = null;
			for(int i = 0; i < size; i++)
			{
				align = new Alignment();
				align.setSubject(subjects.get(i));
				align.setPredicate(predicates.get(i));
				align.setObject(objects.get(i));
				align.setWeight(Double.parseDouble(similarity.get(i)));
				
				alignments.add(align);
			}
		}
		return alignments;
	}
	
	/*
	public static ArrayList<String> findNodeInXML(String filePath, String node) throws FileNotFoundException
	{
		ArrayList<String> results = new ArrayList<String>();
		Scanner scan = new Scanner(new File(filePath));
		String fileText = "";
		
		while (scan.hasNextLine())
		{
			fileText += scan.nextLine();
		}
		
		fileText = fileText.replaceAll(" ", "").replaceAll("\n", "");
		
		String[] strings = fileText.split("<" + node + ">");
		
		for(String string : strings)
		{
			int index = string.indexOf("</" + node + ">");
		
		}
		
		return results;
		
	}*/
}
