package speed.ontologymatcher.lematching.enums;

/**
 * Enum com os tipos de alinhamentos poss�veis.
 * @author Thiago Pach�co Andrade Pereira
 *
 */
public enum EMappingType {
	
	ONE_TO_ONE("1:1"),
	ONE_TO_MANY("1:N")
	;
	
	private String str = null;
	
	private EMappingType(String toStr)
	{
		this.str = toStr;		
	}
	@Override	
	public String toString() {
		return this.str;
	}
}
