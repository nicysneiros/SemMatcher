package speed.ontologymatcher.lematching.enums;

/**
 * Enum com os tipos de relacionamentos poss�veis em um alinhamento.
 * @author Thiago Pach�co Andrade Pereira
 *
 */
public enum ERelation {

	NONE(""),
	EQUIVALENT("=");
	
	private String str = null;
	
	private ERelation(String toStr)
	{
		this.str = toStr;		
	}
	@Override	
	public String toString() 
	{
		return this.str;
	}
	
	public static ERelation createERelation(String relationName)
	{
		if(relationName.equalsIgnoreCase(EQUIVALENT.str))
		{
			return ERelation.EQUIVALENT;
		}
		else
		{
			return ERelation.NONE;			
		}
	}
	
}
