package speed.ontologymatcher.lematching.enums;

/**
 * Enum com o tipo de matching a ser usado.
 * Obs: Apenas o tipo LINGUISTIC_STRUCTURAL est� implementado. 
 * @author Thiago Pach�co Andrade Pereira.
 *
 */
public enum EMatcher {
	
	LINGUISTIC("l"),
	CONTEXTUAL("c"),
	STRUCTURAL("s"),
	INSTANCE("i"),
	LINGUISTIC_STRUCTURAL("ls");
	;
	
	private String str = null;
	
	private EMatcher(String toStr)
	{
		this.str = toStr;		
	}
	@Override	
	public String toString() {
		return this.str;
	}
}
