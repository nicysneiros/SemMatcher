package speed.ontologymatcher.lematching.matcher;

import islab.hmatch.CommandLineHMatch;
import islab.hmatch.DeepMatching;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Vector;

import org.apache.log4j.PropertyConfigurator;

import speed.ontologymatcher.lematching.basics.LEAlignment;
import speed.ontologymatcher.lematching.enums.EMappingType;
import speed.ontologymatcher.lematching.enums.EMatcher;
import speed.ontologymatcher.lematching.enums.ERelation;
import speed.ontologymatcher.lematching.util.FileHandler;
import speed.ontologymatcher.lematching.util.XMLParser;
import speed.ontologymatcher.util.OntologyMatcherProperties;

import com.hp.hpl.jena.ontology.DatatypeProperty;
import com.hp.hpl.jena.ontology.ObjectProperty;
import com.hp.hpl.jena.ontology.OntClass;
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.ontology.OntModelSpec;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.util.FileManager;
import com.hp.hpl.jena.util.iterator.ExtendedIterator;
import common.Ontology;
import common.PropertyFinder;

import coordination.HMatchController;
import coordination.History;

/**
 * Classe com m�todos para gerenciar o uso de matcher lingu�stico-estruturais.
 * Pode fazer uso dos seguintes matcher:
 * 	- Hmatch 2.0 cmd
 *  - Alignment API
 *  - HMatchCL 2.0
 * @author Thiago Pach�co Andrade Pereira
 *
 */
public class LEMatcherManager {

	private HMatchController controller;

	private History operationsHistory;

	private ArrayList<Integer> mappingIDs;

	/**
	 * Construtor default.
	 */
	public LEMatcherManager() {
		PropertyFinder pFinder = PropertyFinder.getInstance();
		PropertyConfigurator.configure(pFinder.getLogConfigurationFile());
		this.controller = HMatchController.getInstance();
		this.operationsHistory = new History();
		this.mappingIDs = new ArrayList<Integer>();
	}

	/**
	 * M�todo que executa o matching linguistico-estrutural com uso de um matcher externo.
	 * @param fileOntology1 Caminho da ontologia de entrada 1.
	 * @param fileOntology2 Caminho da ontologia de entrada 2.
	 * @param fileOut Caminho do arquivo de sa�da.
	 * @param mappingType Tipo do alinhamento (1:1, 1:N, N:M).
	 * @param matcher Tipo de matching a ser realizado. 
	 * @return Retorna uma lista de alinhamentos.
	 */
	public ArrayList<LEAlignment> executeLEMAtching(String fileOntology1,
			String fileOntology2, String fileOut, EMappingType mappingType,
			EMatcher matcher) {
		ArrayList<LEAlignment> matchings = new ArrayList<LEAlignment>();

		if (OntologyMatcherProperties.MATCHER == 1) {

			Ontology ontology1 = Ontology
					.createOntology(new File(fileOntology1));
			Ontology ontology2 = Ontology
					.createOntology(new File(fileOntology2));

			if (ontology1 != null && ontology2 != null) {

				mappingIDs.add(Integer.valueOf(controller
						.executeLinguisticMatching(ontology1, ontology2)));

				operationsHistory.recordMatchingOperation(matcher.toString(),
						fileOntology1, fileOntology2, new Vector<Integer>(
								mappingIDs));

				Integer id = mappingIDs.get(mappingIDs.size() - 1);

				FileHandler.createMatchingFile(fileOut, mappingType, id);

				try {
					ArrayList<String> entities1 = XMLParser.findNodeInAlignmentFile(fileOut,
							"entity1");
					ArrayList<String> entities2 = XMLParser.findNodeInAlignmentFile(fileOut,
							"entity2");
					ArrayList<String> measures = XMLParser.findNodeInAlignmentFile(fileOut,
							"measure");
					ArrayList<String> relations = XMLParser.findNodeInAlignmentFile(fileOut,
							"relation");

					for (int i = 0; i < entities1.size(); i++) {
						LEAlignment matchingItem = new LEAlignment(entities1
								.get(i), entities2.get(i), Double
								.parseDouble(measures.get(i)), ERelation
								.createERelation(relations.get(i)));
						if (entities1.get(i) != null
								&& entities2.get(i) != null
								&& !entities1.get(i).split("#")[1].equalsIgnoreCase("PartOf")
								&& !entities2.get(i).split("#")[1].equalsIgnoreCase("PartOf"))
							matchings.add(matchingItem);
					}

				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}

				operationsHistory.recordMappingSave(id.intValue(), fileOut,
						mappingType.toString());

				// Analise estrutural

				int idNew = controller.executeStructuralMatching(ontology1,
						ontology2, id);

				mappingIDs.add(Integer.valueOf(idNew));

				id = mappingIDs.get(mappingIDs.size() - 1);

				FileHandler.createMatchingFile(fileOut, mappingType, id);

				try {
					ArrayList<String> entities1 = XMLParser.findNodeInAlignmentFile(fileOut,
							"entity1");
					ArrayList<String> entities2 = XMLParser.findNodeInAlignmentFile(fileOut,
							"entity2");
					ArrayList<String> measures = XMLParser.findNodeInAlignmentFile(fileOut,
							"measure");
					ArrayList<String> relations = XMLParser.findNodeInAlignmentFile(fileOut,
							"relation");

					for (int i = 0; i < entities1.size(); i++) {
						LEAlignment matchingItem = new LEAlignment(entities1
								.get(i), entities2.get(i), Double
								.parseDouble(measures.get(i)), ERelation
								.createERelation(relations.get(i)));
						if (entities1.get(i) != null
								&& entities2.get(i) != null
								&& !entities1.get(i).contains("PartOf")
								&& !entities2.get(i).contains("PartOf"))
							matchings.add(matchingItem);
					}
					System.out.println();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				operationsHistory.recordMappingSave(id.intValue(), fileOut,
						mappingType.toString());

			} else {

				System.out.println("ERROR: File not found.");

			}
		} else if (OntologyMatcherProperties.MATCHER == 2) {
			try {
				fileOntology1 = fileOntology1.replace('\\', '/');
				fileOntology2 = fileOntology2.replace('\\', '/');
				fileOut = fileOut.replace('\\', '/');
				
				String ontology1 = "file:///" + fileOntology1;
				String ontology2 = "file:///" + fileOntology2;
				String output =  fileOut;
				
				Process proc = Runtime
						.getRuntime()
						.exec(
								"java -jar "+ OntologyMatcherProperties.ALIGNMENTAPI_PATH + "procalign.jar " + ontology1 + " " + ontology2 + " -o " + output + " -t 0.0" );
				
				/*InputStream inputStream = proc.getInputStream();
				ByteArrayOutputStream bais = new ByteArrayOutputStream();
				int lido = 0;
				while ((lido = inputStream.read()) > 0) {
					bais.write(lido);
				}
				System.out.println(new String(bais.toByteArray()));*/
				
				boolean finished = false;
				
				while(!finished)
				{
					try {
						proc.exitValue();
						finished = true;
					} catch (IllegalThreadStateException e) {}
				}
				
				try {
					ArrayList<String> entities1 = XMLParser.findNodeInAlignmentFile(fileOut,
							"entity1");
					ArrayList<String> entities2 = XMLParser.findNodeInAlignmentFile(fileOut,
							"entity2");
					ArrayList<String> measures = XMLParser.findNodeInAlignmentFile(fileOut,
							"measure");
					ArrayList<String> relations = XMLParser.findNodeInAlignmentFile(fileOut,
							"relation");

					for (int i = 0; i < entities1.size(); i++) {
						LEAlignment matchingItem = new LEAlignment(entities1
								.get(i), entities2.get(i), Double
								.parseDouble(measures.get(i)), ERelation
								.createERelation(relations.get(i)));
						if (entities1.get(i) != null
								&& entities2.get(i) != null
								&& !entities1.get(i).contains("PartOf")
								&& !entities2.get(i).contains("PartOf"))
							matchings.add(matchingItem);
					}
					System.out.println();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			
			
		}
		else if(OntologyMatcherProperties.MATCHER == 3)
		{	
			fileOntology1 = fileOntology1.replace('\\', '/');
			fileOntology2 = fileOntology2.replace('\\', '/');
			fileOut = fileOut.replace('\\', '/');
			
			String mappingTypeFile = "policy11.xml";
			
			switch (mappingType) {
			case ONE_TO_ONE:
				mappingTypeFile = "policy11.xml";
				break;
			case ONE_TO_MANY:
				mappingTypeFile = "policy1N.xml";
				break;
			default:
				break;
			}
			
			String[] arguments = new String[]{ 
					mappingTypeFile, 
					fileOntology1 , 
					fileOntology2, 
					"true", 
					"true", 
					fileOut };
			
			CommandLineHMatch.main(arguments);
			DeepMatching.revalidateThesaurus();
			try {
				ArrayList<String> entities1 = XMLParser.findNodeInAlignmentFile(fileOut,
						"entity1");
				ArrayList<String> entities2 = XMLParser.findNodeInAlignmentFile(fileOut,
						"entity2");
				ArrayList<String> measures = XMLParser.findNodeInAlignmentFile(fileOut,
						"measure");
				ArrayList<String> relations = XMLParser.findNodeInAlignmentFile(fileOut,
						"relation");

				for (int i = 0; i < entities1.size(); i++) {
					LEAlignment matchingItem = new LEAlignment(entities1
							.get(i), entities2.get(i), Double
							.parseDouble(measures.get(i)), ERelation
							.createERelation(relations.get(i)));
					if (entities1.get(i) != null
							&& entities2.get(i) != null
							&& !entities1.get(i).contains("PartOf")
							&& !entities2.get(i).contains("PartOf"))
						matchings.add(matchingItem);
				}
				System.out.println();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}

		return matchings;
	}

	public ArrayList<LEAlignment> executeLEMAtchingNormalized(String fileOntology1,
			String fileOntology2)
	{	
		ArrayList<LEAlignment> alignments = new ArrayList<LEAlignment>();
		
		Model ontology1 = FileManager.get().loadModel("file://" + fileOntology1);
		Model ontology2 = FileManager.get().loadModel("file://" + fileOntology2);
		
		String URI2 = ontology2.getNsPrefixURI("");
		
		OntModelSpec spec = new OntModelSpec(OntModelSpec.OWL_DL_MEM_TRANS_INF);
		OntModelSpec spec2 = new OntModelSpec(OntModelSpec.OWL_DL_MEM_TRANS_INF);
		OntModel model1 = ModelFactory.createOntologyModel(spec, ontology1);
		OntModel model2 = ModelFactory.createOntologyModel(spec2, ontology2);
		
		//Classes
		ExtendedIterator it = model1.listClasses();
		
		while(it.hasNext())
		{	
			String clazz = String.valueOf(it.next());
			String[] uri_class = clazz.split("#");
			
			if(uri_class.length == 2 && uri_class[1] != null && !uri_class[1].isEmpty())
			{
				OntClass clazzObj = model2.getOntClass(URI2 + uri_class[1]);
				
				if(clazzObj != null)
				{
					LEAlignment align = new LEAlignment(clazz, clazzObj.getURI(), 1.0, ERelation.EQUIVALENT);
					alignments.add(align);
				}
			}
		}
		
		//Datatype properties
		ExtendedIterator it2 = model1.listDatatypeProperties();
		
		while(it2.hasNext())
		{	
			String property = String.valueOf(it2.next());
			String[] uri_property = property.split("#");
			
			if(uri_property.length == 2 && uri_property[1] != null && !uri_property[1].isEmpty())
			{
				DatatypeProperty propertyObj = model2.getDatatypeProperty(URI2 + uri_property[1]);
				
				if(propertyObj != null)
				{
					LEAlignment align = new LEAlignment(property, propertyObj.getURI(), 1.0, ERelation.EQUIVALENT);
					alignments.add(align);
				}
			}
		}
		
		//Object Properties
		ExtendedIterator it3 = model1.listObjectProperties();
		
		while(it3.hasNext())
		{	
			String property = String.valueOf(it3.next());
			String[] uri_property = property.split("#");
			
			if(uri_property.length == 2 && uri_property[1] != null && !uri_property[1].isEmpty())
			{
				ObjectProperty propertyObj = model2.getObjectProperty(URI2 + uri_property[1]);
				
				if(propertyObj != null)
				{
					LEAlignment align = new LEAlignment(property, propertyObj.getURI(), 1.0, ERelation.EQUIVALENT);
					alignments.add(align);
				}
			}
		}
		
		return alignments;
	}
	
	
	/**
	 * M�todo que executa o matching linguistico-estrutural com uso de um matcher externo.
	 * Gera matching entre as ontologias locais (CLOs) e a de dom�nio (CMO).
	 * @param fileCLOi Caminho da ontologia local CLOi.
	 * @param fileCLOj Caminho da ontologia local CLOj.
	 * @param fileCMO Caminho da ontologia local CMO.
	 * @return Retorna 2 listas de matching:
	 * 				- Entre a CLOi e CMO.
	 * 				- Entre a CLOj e CMO.
	 */
	public ArrayList<ArrayList<LEAlignment>> executeLEMatchingWithCMO(String fileCLOi, String fileCLOj, String fileCMO)
	{
		ArrayList<ArrayList<LEAlignment>> alignments = new ArrayList<ArrayList<LEAlignment>>();
		
		String outPath2 = fileCMO.substring(0, fileCMO.lastIndexOf("\\"));
		
		ArrayList<LEAlignment> matchingsCLOi = this.executeLEMAtching(fileCLOi, fileCMO, outPath2 + "/MatchingFileCLOi.rdf", EMappingType.ONE_TO_ONE, EMatcher.LINGUISTIC_STRUCTURAL);
		ArrayList<LEAlignment> matchingsCLOj = this.executeLEMAtching(fileCLOj, fileCMO, outPath2 + "/MatchingFileCLOj.rdf", EMappingType.ONE_TO_ONE, EMatcher.LINGUISTIC_STRUCTURAL);
		
		alignments.add(matchingsCLOi);
		alignments.add(matchingsCLOj);
					
		return alignments;
	}

	public ArrayList<ArrayList<LEAlignment>> executeLEMatchingWithCMONormalized(String fileCLOi, String fileCLOj, String fileCMO)
	{
		ArrayList<ArrayList<LEAlignment>> alignments = new ArrayList<ArrayList<LEAlignment>>(2);
		
		ArrayList<LEAlignment> matchingsCLOi = this.executeLEMAtchingNormalized(fileCLOi, fileCMO);
		ArrayList<LEAlignment> matchingsCLOj = this.executeLEMAtchingNormalized(fileCLOj, fileCMO);
		
		alignments.add(matchingsCLOi);
		alignments.add(matchingsCLOj);
		
		return alignments;
	}
	
}
