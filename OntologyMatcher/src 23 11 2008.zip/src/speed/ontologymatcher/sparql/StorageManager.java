package speed.ontologymatcher.sparql;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import speed.ontologymatcher.semanticmatching.basics.Alignment;
import speed.ontologymatcher.util.OntologyMatcherProperties;

import com.hp.hpl.jena.db.DBConnection;
import com.hp.hpl.jena.db.IDBConnection;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.ModelMaker;

/**
 * Classe que gerencia armazenamento de ontologias.
 * @author Thiago Pach�co Andrade Pereira
 *
 */
public class StorageManager {
	
	/**
	 * M�todo que gera um arquivo RDF a partir dos matching sem�nticos.
	 * @param alignments Alinhamentos sem�nticos.
	 * @param outputPath Caminho do arquivo de sa�da.
	 * @throws FileNotFoundException Caso o arquivo n�o consiga ser criado.
	 */
	public static void saveSemanticAlignmentsToRDF(ArrayList<Alignment> alignments, String outputPath)
			throws FileNotFoundException {
		
		Model model = Alignment.createJenaModelFromAlignment(alignments);
		FileOutputStream stream = new FileOutputStream(new File(outputPath));
		model.write(stream);
		try {
			stream.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * M�todo que gera um arquivo com informa��es dos alinhamentos.
	 * @param alignments Alinhamentos.
	 * @param outputPath Caminho do arquivo de sa�da.
	 */
	public static void saveToFile(ArrayList<Alignment> alignments,
			String outputPath) {
		String content = "";
		
		for (Alignment statement : alignments) {
		
			content += "<Match>\n" +
						"\t<Subject>" + statement.getSubject() + "</Subject>\n" +
						"\t<Predicate>" + statement.getPredicate() + "</Predicate>\n" +
						"\t<Object>" + statement.getObject() + "</Object>\n" +
						"\t<Similarity>" + (statement.getWeight() == -1.0 ? "Indefinido" : statement.getWeight()) + "</Similarity>\n" +
						"</Match>\n";
		}
		
		try {

			FileWriter fileWriter = new FileWriter(outputPath, true);			
			fileWriter.write(content); 
			fileWriter.close();
		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * M�todo que salva os alinhamentos sem�nticos no banco de dados.
	 * @param alignments Alinhamentos sem�nticos.
	 * @param schemaName Nome do esquema no banco.
	 */
	public static void saveToDB(ArrayList<Alignment> alignments, String schemaName) {

		Model model = Alignment.createJenaModelFromAlignment(alignments);
		
		try {
			Class.forName(OntologyMatcherProperties.DB_DRIVER);
		} catch (Exception e) {
			e.printStackTrace();
		}

		ModelMaker maker = null;

		try {
			IDBConnection conn = new DBConnection(OntologyMatcherProperties.DB_URL,
					OntologyMatcherProperties.DB_USER, OntologyMatcherProperties.DB_PASSWD, OntologyMatcherProperties.DB);
			maker = ModelFactory.createModelRDBMaker(conn);
		} catch (Exception e) {
			e.printStackTrace();
		}

		maker.createModel(schemaName);

		maker.getModel(schemaName).add(model);		

	}

}
