package speed.ontologymatcher.sparql;

/**
 * Classe b�sica que representa um statement owl.
 * @author Thiago Pach�co Andrade Pereira
 *
 */
public class SpeedStatement {
	
	/**
	 * Sujeito
	 */
	private String subject;
	/**
	 * Predicado
	 */
	private String predicate;
	/**
	 * Objeto
	 */
	private String object;
	
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getSubject() {
		return subject;
	}
	public void setPredicate(String predicate) {
		this.predicate = predicate;
	}
	public String getPredicate() {
		return predicate;
	}
	public void setObject(String object) {
		this.object = object;
	}
	public String getObject() {
		return object;
	}

}
